<?php 
require_once 'latihan10.php';

$ac1 = new Account(" 03201",5000000);
$ac2 = new Account(" 01010",4500000);

$ac1->cetak();
echo '<hr>';
$ac2->cetak();
echo '<hr>';
$ac1->deposit(75000);
echo 'Nabung 75000 <br>';
$ac1->cetak();
 ?>