<?php 
require_once 'class_BankAccount.php';

$ab1 = new BankAccount("010",5000000,"Messi");
$ab2 = new BankAccount("007",4500000,"Ronaldo");

$ab1->cetak();
echo '<hr>';
$ab2->cetak();
echo '<br>Ronaldo transfer uang ke Messi 1250000 <br>';
echo 'Biaya Admin : '.BankAccount::$biaya_admin.'<br>';
$ab2->transfer($ab1,1250000);
$ab1->cetak();
echo '<hr>';
$ab2->cetak();

$ar_ab =[$ab1,$ab2];
 ?>